package com.automation.steps;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.time.Duration;

public class HomeSteps extends BaseTest{
    WebDriver driver;

    @FindBy(xpath = "(//img[@title = 'Royal Brothers'])")
    WebElement title;

    @FindBy(xpath = "(//img[@alt = 'Select Bangalore'])")
    WebElement bangaloreCity;

    @Test(priority = 1)
    public void user_is_on_home_page() {
        Assert.assertTrue(homePage.isTitlePresent());
    }

    @Test(priority = 2)
    public void user_user_selects_bangalore_city() {
        homePage.selectBangaloreCity();
        Assert.assertTrue(homePage.isBangaloreSelected());
    }

    @Test
    public void user_selects_dates_for_vehicle() {
        homePage.selectPickupDate();
    }
}
