package com.automation.steps;

import com.automation.pages.HomePage;
import com.automation.utils.DriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;

public class BaseTest {
    HomePage homePage;
    WebDriver driver;

    @BeforeTest
    public void setUp(){
        DriverManager.createDriver();
        driver.get("https://www.royalbrothers.com/");
        homePage = new HomePage();
    }

    @AfterTest
    public void cleanUp() {
        driver.quit();
    }
}
