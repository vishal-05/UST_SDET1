package com.automation.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.time.Duration;

public class HomePage extends BasePage{

    @FindBy(xpath = "(//img[@title = 'Royal Brothers'])")
    WebElement title;

    @FindBy(xpath = "(//img[@alt = 'Select Bangalore'])")
    WebElement bangaloreCity;

    @FindBy(xpath = "(//span[@data-current_city='Bangalore'])")
    WebElement bangloreSelectBox;

    @FindBy(xpath = "(//div[@class='ecomsend-SpinWheel__Modal__CloseButton _closeBtn_rg2mi_33'])")
    WebElement loginBtn;

    @FindBy(xpath = "(//input[@id='phone_no'])")
    WebElement phoneNumber;

    @FindBy(xpath = "(//input[@id='session_password'])")
    WebElement passwordBox;


    @FindBy(xpath="(//div[@class='recaptcha-checkbox-border'])")
    WebElement captcha;

    @FindBy(xpath="(//button[@type='submit'])")
    WebElement lgnBtn;

    public void openWebsite() {
        driver.get("https://store.royalbrothers.com/collections/t-shirts/products/sunset-t-shirt");
    }

    public boolean isTitlePresent() {
        return title.isDisplayed();
    }

    public void selectBangaloreCity(){
        bangaloreCity.click();
    }

    public boolean isBangaloreSelected() {
        return bangloreSelectBox.isDisplayed();
    }

    public void selectPickupDate() {
       loginBtn.click();
       phoneNumber.sendKeys("988698547");
       passwordBox.sendKeys("qEbvYME@Z@MXx9V");
       captcha.click();
       loginBtn.click();
    }


}
