package com.automation.pages;

import com.automation.utils.ConfigReader;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;

import java.time.Duration;

public class HomePage extends BasePage{
    @FindBy(xpath = "(//img[@title = 'Royal Brothers'])")
    WebElement title;

    @FindBy(xpath = "(//img[@alt = 'Select Bangalore'])")
    WebElement bangaloreCity;

    @FindBy(xpath = "(//span[@data-current_city='Bangalore'])")
    WebElement bangloreSelectBox;


    @FindBy(xpath = "(//a[@class='btn btn-login hide-on-med-and-down access_button'])")
    WebElement loginBtn;

    @FindBy(xpath = "(//input[@id='phone_no'])")
    WebElement phoneNumber;

    @FindBy(xpath = "(//input[@id='session_password'])")
    WebElement passwordBox;
    @FindBy(xpath = "(//span[@id='rental_amount'])")
    WebElement amount;

    @FindBy(xpath = "(//h6[@class='valign-wrapper center-align bike_name'])")
    WebElement vehicleName;


    @FindBy(xpath="(//div[@class='recaptcha-checkbox-border'])")
    WebElement captcha;

    @FindBy(xpath="(//button[@type='submit'])")
    WebElement lgnBtn;

    @FindBy(xpath = "(//input[@class='loc_input'])")
    WebElement selectLocation;

    @FindBy(xpath = "(//button[@class='waves-effect black-text waves-light btn right fullWidthButton font1 book_button'])")
    WebElement bookbtn;

    public void openWebsite() {
        driver.get("https://www.royalbrothers.com/");
    }

    public boolean isTitlePresent() {
        return title.isDisplayed();
    }

    public void selectBangaloreCity(){
        bangaloreCity.click();
    }

    public boolean isBangaloreSelected() {
        return bangloreSelectBox.isDisplayed();
    }

    public void login() {
       loginBtn.click();
       phoneNumber.sendKeys("988698547");
       passwordBox.sendKeys("qEbvYME@Z@MXx9V");
        wait.withTimeout(Duration.ofSeconds(10));
       wait.withTimeout(Duration.ofSeconds(10));
       loginBtn.click();
        System.out.println("Clicked button");
    }

    public void selectLocationAndEnter() {
        System.out.println(vehicleName.getText());
        System.out.println(amount.getText());

    }



}
