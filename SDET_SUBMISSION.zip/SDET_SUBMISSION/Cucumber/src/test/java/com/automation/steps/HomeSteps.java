package com.automation.steps;

import com.automation.pages.HomePage;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.qameta.allure.Allure;
import org.junit.Assert;

public class HomeSteps {
    HomePage homePage = new HomePage();
    @Given("user is on home page")
    public void user_is_on_home_page() {
        homePage.openWebsite();
        Assert.assertTrue(homePage.isTitlePresent());
        Allure.addAttachment("screensshot", homePage.takeScreenshot());
    }
    @When("user user selects bangalore city")
    public void user_user_selects_bangalore_city() {
        homePage.selectBangaloreCity();
        Assert.assertTrue(homePage.isBangaloreSelected());
        Allure.addAttachment("screensshot", homePage.takeScreenshot());

    }
    @And("user login")
    public void user_selects_dates_for_vehicle() {
        homePage.login();
        Allure.addAttachment("screensshot", homePage.takeScreenshot());

    }
    @When("user wants to book first vehicle available")
    public void user_wants_to_book_first_vehicle_available() {
        homePage.selectLocationAndEnter();
        Allure.addAttachment("screensshot", homePage.takeScreenshot());


    }
    @Then("print first vehicle from searched dates total amount")
    public void print_its_total_amount() {
        homePage.selectLocationAndEnter();
        Allure.addAttachment("screensshot", homePage.takeScreenshot());

    }


}
